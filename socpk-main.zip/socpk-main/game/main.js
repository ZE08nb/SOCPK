

function ChangeView(brand){
	window.location.href='../';
}



	